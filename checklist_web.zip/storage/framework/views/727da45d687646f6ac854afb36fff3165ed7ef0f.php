<?php $__env->startSection('title', 'Checklist Peralatan'); ?>

<?php $__env->startSection('konten'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Items</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/pages/items/perangkat">Perangkat</a></li>
                        <li class="breadcrumb-item active">Edit Perangkat</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Perangkat</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="POST" action="/pages/items/perangkat/update/<?php echo e($item->id); ?>">
                            <?php echo csrf_field(); ?>
                            <form role="form">
                                <div class="card-body col-md-6">
                                    <div class="form-group">
                                        <label>Nama Layanan</label>
                                            <select class="form-control" name="nama_layanan">
                                                <option>--Piilih Layanan--</option>
                                                <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($layanan->id); ?>"><?php echo e($layanan->nama_layanan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has("layanans_id")): ?>
                                            <div class="alert alert-danger" role="alert" style="margin-top: 5px;padding-top: 5px;padding-bottom: 5px;padding-left: 13px;padding-right: 5px;margin-right: 330px;" >
                                                <?php echo e(($errors->has("layanans_id"))? $errors->first("layanans_id"):""); ?>

                                            </div>
                                            <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label>Tipe Objek</label>
                                            <select class="form-control" name="tipe_objeks">
                                                <option>--Piilih Objek--</option>
                                                <?php $__currentLoopData = $objek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($objek->id); ?>"><?php echo e($objek->tipe_objeks); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has("objeks_id")): ?>
                                            <div class="alert alert-danger" role="alert" style="margin-top: 5px;padding-top: 5px;padding-bottom: 5px;padding-left: 13px;padding-right: 5px;margin-right: 330px;" >
                                                <?php echo e(($errors->has("objeks_id"))? $errors->first("objeks_id"):""); ?>

                                            </div>
                                            <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Nama Perangkat</label>
                                        <input id="nama_perangkats" type="text" class="form-control <?php $__errorArgs = ['tipe_objeks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"name="nama_perangkats" value="<?php echo e($item->nama_perangkats); ?>" placeholder="Masukkan nama perangkat" required autocomplete="nama_perangkats" autofocus>
                                    </div>
                            </div>
                    <!-- /.card-body -->
                    
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="/pages/items/perangkat" class="btn btn-primary">Kembali</a>
                    </div>
                </form>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\checklist_web\resources\views/pages/items/perangkat/edit_perangkat.blade.php ENDPATH**/ ?>