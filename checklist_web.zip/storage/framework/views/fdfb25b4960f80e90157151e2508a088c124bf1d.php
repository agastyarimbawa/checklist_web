<html>
	<head>
		<title>Login - Checklist Peralatan</title>
		<meta charset="utf-8">
    	<meta content="width=device-width, initial-scale=1" name="viewport">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/themify-icons.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="container">
			<div class="row justify-content-md-center mt-12">
				<div class="col-sm-8">
					<div class="row border-box">
						<div class="col-sm-6 p-0">
							<img src="img/elektro-login.jpg" class="img-fluid">
						</div>
						<div class="col-sm-6 p-0">
							<div class="card">
								<div class="card-header">
									<img src="img/mz-logo-login.png">
									<div class="sub-title">
										Masuk dashboard administrator/teknisi
									</div>
								</div>
								<div class="icon-user">
									<h4 class="ti-user"></h4>
								</div>
								<div class="card-body">
									<form method="POST" action="<?php echo e(route('login')); ?>">
									<?php echo csrf_field(); ?>
									  <div class="input-group mb-3">
										  <div class="input-group-prepend">
										    <span class="input-group-text"><i class="ti-email"></i></span>
										  </div>
											<input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>"required autocomplete="email" autofocus placeholder="username">
											  
											<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>
									  <div class="input-group mb-3">
										  <div class="input-group-prepend">
										    <span class="input-group-text"><i class="ti-lock"></i></span>
										  </div>
										  	<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required 	autocomplete="current-password" placeholder="password">

                                			<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    			<span class="invalid-feedback" role="alert">
                                        			<strong><?php echo e($message); ?></strong>
                                    			</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>
									  <div class="form-group">
									  	 <label class="mz-check">
										</label>
										<label class="float-right"><a href="">Lupa Sandi?</a></label>
									  </div>
									  <button type="submit" class="btn btn-primary">
										<?php echo e(__('Login')); ?>

									  </button>
									</form>
								</div>
								
							</div>
						</div>
					</div>
					<div class="mt-4 text-right">
						<small><?php echo e(date("Y")); ?> &copy; Created By - Agas</small>
					</div>
				</div>
				
			</div>
		</div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\checklist_web\resources\views/login.blade.php ENDPATH**/ ?>