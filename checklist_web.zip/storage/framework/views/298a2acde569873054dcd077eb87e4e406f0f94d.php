<?php $__env->startSection('title', 'Checklist Peralatan'); ?>

<?php $__env->startSection('konten'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Items</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/pages/items/lokasi">Lokasi</a></li>
                        <li class="breadcrumb-item active">Edit Lokasi</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit Lokasi</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="POST" action="/pages/items/lokasi/update/<?php echo e($item->id); ?>">
                            <?php echo csrf_field(); ?>
                            <form role="form">
                                <div class="card-body col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Nama Lokasi</label>
                                        <input id="nama_lokasi" type="text" class="form-control <?php $__errorArgs = ['nama_lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> ? ' is-invalid' : '' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_lokasi" value="<?php echo e($item->nama_lokasi); ?>" required autocomplete="nama_lokasi" autofocus>
                                        <?php if($errors->has("nama_lokasi")): ?>
                                            <div class="alert alert-danger" role="alert" style="margin-top: 5px;padding-top: 5px;padding-bottom: 5px;padding-left: 13px;padding-right: 5px;margin-right: 330px;" >
                                                <?php echo e(($errors->has("nama_lokasi"))? $errors->first("nama_lokasi"):""); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                    <a href="/pages/items/lokasi" class="btn btn-primary">Kembali</a>
                                </div>
                            </form>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\checklist_web\resources\views/pages/items/lokasi/edit_lokasi.blade.php ENDPATH**/ ?>