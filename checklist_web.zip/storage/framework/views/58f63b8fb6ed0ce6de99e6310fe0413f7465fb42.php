<?php $__env->startSection('title', 'Checklist Peralatan'); ?>

<?php $__env->startSection('konten'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Items</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="/pages/alat/perangkat">Perangkat</a></li>
              <li class="breadcrumb-item active">Daftar Perangkat</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <a href="/pages/alat/perangkat/tambah" class="btn btn-block btn-sm btn-primary col-1"><i class="fas fa-plus-circle">&nbsp;</i>Tambah</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Kode Perangkat</th>
                  <th>Nama Layanan</th>
                  <th>Object Type</th>
                  <th>Nama Perangkat</th>
                  
                  
                  <th>Act</th>
                </tr>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                <tr>
                  <td><?php echo $item->id; ?></td>
                  <td><?php echo $item->nama_layanan; ?></td>
                  <td><?php echo $item->tipe_objeks; ?></td>
                  <td><?php echo $item->nama_perangkats; ?></td>
                  
                  
                  <td width="103px">
                    <div class="">
                    <a class="btn btn-block btn-sm btn-success col-12 d-inline" href="/pages/alat/perangkat/edit/<?php echo e($item->id); ?>">Edit</a>
                    <a class="btn btn-block btn-sm btn-danger col-12 d-inline" href="/pages/alat/perangkat/delete/<?php echo e($item->id); ?>">Hapus</a>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\checklist_web\resources\views/pages/alat/perangkat/perangkat.blade.php ENDPATH**/ ?>